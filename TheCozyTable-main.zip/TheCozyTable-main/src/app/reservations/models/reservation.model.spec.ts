import { Reservation } from './reservation.model';

describe('Reservation', () => {
  it('should create an instance', () => {
    expect(new Reservation()).toBeTruthy();
  });
});
