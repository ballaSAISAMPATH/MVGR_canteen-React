export interface User {
    id: string;
    FullName: string;
    MobileNumber: number;
    EmailAddress: string;
    Password: string;
    Role: string;
  }
  