// import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
// import { BrowserModule } from '@angular/platform-browser';
// import { FormsModule } from '@angular/forms'; // Ensure this is the correct import
// import { AppComponent } from './app.component';
// import { ReservationComponent } from './reservations/components/reservation/reservation.component';

// @NgModule({
//   declarations: [
//     AppComponent,
//     ReservationComponent, // Add all components used in this module
//   ],
//   imports: [
//     BrowserModule,
//     FormsModule, // Ensure this is listed in imports
//   ],
//   schemas: [CUSTOM_ELEMENTS_SCHEMA], // Add if using Web Components
//   bootstrap: [AppComponent]
// })
// export class AppModule { }
