export interface OrderSummary {
    id: string;
    status: string;
    progress?: number;  // Optional field, can be undefined
  }
  