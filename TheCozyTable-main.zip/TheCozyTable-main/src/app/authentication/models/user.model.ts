export interface User {
    id?: string; 
    FullName: string;
    EmailAddress: string;
    MobileNumber: number;
  }
  